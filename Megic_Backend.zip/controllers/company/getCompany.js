const {
  CompanyInfo,
  BankingInformation,
  MiscSetting,
  BillingInformation,
} = require("../../models/company");

const getCompany = async (req, res) => {
  const { id } = req.params;
  try {
    const company = await CompanyInfo.findOne({ _id: id });
    const billing = await BillingInformation.findOne({ compid: id });
    const banking = await BankingInformation.findOne({ compid: id });
    const misc = await MiscSetting.findOne({ compid: id });
    res.status(200).json({
      status: true,
      error: false,
      msg: "company information gets successfully",
      data: {
        company,
        billing,
        banking,
        misc,
      },
    });
  } catch (err) {
    res.status(404).json({
      status: false,
      error: true,
      msg: "company is not found",
    });
  }
};

module.exports = {
  getCompany,
};
