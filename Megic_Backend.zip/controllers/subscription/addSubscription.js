const Subscriptions = require("../../models/subscription");
const { requireFieldErrorMessege } = require("../../services/validation");

const addSubscription = async (req, res) => {
  try {
    const subscriptionData = req.body;
    const subscription = await Subscriptions.create(subscriptionData);
    res.status(200).json({
      status: true,
      error: false,
      msg: "subscription added successfully.",
      data: {
        subscription,
      },
    });
  } catch (err) {
    let errors = "";
    if (err.name === "ValidationError") {
      errors = requireFieldErrorMessege(err);
      res.status(401).json({
        status: false,
        error: true,
        msg: errors,
      });
    } else {
      res.status(500).json({
        status: false,
        error: true,
        msg: "internal error",
      });
    }
  }
};

module.exports = {
  addSubscription,
};
